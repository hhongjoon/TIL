### README _ 2반 성홍준

```
project0125/
	README.md
	01_layout.html
    01_layout.css
    02_movie.html
    02_movie.css
    03_detail_view.html
    03_detail_view.css
    assets/*.jpg


```

* 주석으로 구분하였습니다.

